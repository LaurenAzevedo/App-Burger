package br.ulbra.burguerapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Catalogo2 extends AppCompatActivity {
    TextView textView15;
        DBHelperProd dbp;
        Button btnBebidas, btnVoltarCadastro;
        String nomeprod,precoprod;
        ImageButton whats;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_catalogo2);
        dbp = new DBHelperProd(this);
        btnBebidas = findViewById(R.id.btnBebidas);
        btnVoltarCadastro = findViewById(R.id.btnVoltarCadastro);
        textView15 = findViewById(R.id.textView15);
        whats = findViewById(R.id.whats);
         btnBebidas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Catalogo2.this, Bebidas1.class);
                startActivity(i);
            }
        });

        btnVoltarCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
                public void onClick(View v) {
                Intent i = new Intent(Catalogo2.this, Cadastro1.class);
                startActivity(i);

            }
        });

            whats.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Uri uri = Uri.parse("https://web.whatsapp.com/");
                    Intent ti = new Intent(Intent.ACTION_VIEW,uri);
                    startActivity(ti);
                }
            });

    }
}