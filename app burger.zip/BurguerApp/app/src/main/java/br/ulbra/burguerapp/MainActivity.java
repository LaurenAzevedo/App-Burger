package br.ulbra.burguerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText edtEmail,edtSenha;
    DBHelper db;
    Button btnEntrar, btnCriarConta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        db = new DBHelper(this);
        edtEmail = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);

        btnEntrar = findViewById(R.id.btnEntrar);
        btnCriarConta = findViewById(R.id.btnCriarConta);

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edtEmail.getText().toString();
                String password = edtSenha.getText().toString();

                if (username.equals("")) {
                    Toast.makeText(MainActivity.this, "Usuario não inserido, tente novamente", Toast.LENGTH_SHORT).show();
                } else if (password.equals("")) {
                    Toast.makeText(MainActivity.this, "Senha não inserida, tente novamente", Toast.LENGTH_SHORT).show();
                } else {
                    String res = db.validarLogin(username, password);
                    if (res.equals("OK")) {
                        Toast.makeText(MainActivity.this, "Login OK !!", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(MainActivity.this, Catalogo2.class);
                        startActivity(i);
                    } else {
                        Toast.makeText(MainActivity.this, "Login ou Senha errado(s)!!", Toast.LENGTH_SHORT).show();
                    }

                }
                ;
            }
        });
        btnCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Cadastro1.class);
                startActivity(i);

            }
        });
    }
    }