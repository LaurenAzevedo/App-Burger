package br.ulbra.burguerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Cadastro1 extends AppCompatActivity {

    EditText edtNomeCadastro, edtEmailCadastro, edtSenhaCadastro, edtTelefoneCadastro;
    DBHelper db;
    Button btnSalvar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro1);
        db = new DBHelper(this);
        edtNomeCadastro = findViewById(R.id.edtNomeCadastro);
        edtEmailCadastro = findViewById(R.id.edtEmailCadastro);
        edtSenhaCadastro = findViewById(R.id.edtSenhaCadastro);
        edtTelefoneCadastro = findViewById(R.id.edtTelefoneCadastro);

        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userName = edtEmailCadastro.getText().toString();
                String pas1 = edtSenhaCadastro.getText().toString();
                Double tel = Double.parseDouble(edtTelefoneCadastro.getText().toString());

                if (userName.equals("")) {
                    Toast.makeText(Cadastro1.this, "Insira o EMAIL DO USUÁRIO", Toast.LENGTH_LONG).show();
                } else if (pas1.equals("") || tel.equals("")){
                    Toast.makeText(Cadastro1.this, "Insira a SENHA DO USUÁRIO", Toast.LENGTH_LONG).show();
                }else if(!tel.equals(tel)){
                    Toast.makeText(Cadastro1.this, "Insira o TELEFONE DO USUÁRIO", Toast.LENGTH_LONG).show();
                }else{
                    long res = db.criarUtilizador(userName,pas1);
                    if(res>0){
//nesta parte você poderá chamar a tela principal do sistema autenticado
                        Toast.makeText(Cadastro1.this, "Resgistro OK", Toast.LENGTH_LONG).show();
                        Intent i = new Intent(Cadastro1.this, MainActivity.class);
                        startActivity(i);
                    }else{
                        Toast.makeText(Cadastro1.this, "Senha inválida!", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


                };
    }
