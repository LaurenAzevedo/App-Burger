package br.ulbra.burguerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

public class DBHelperProd extends SQLiteOpenHelper {
    private static String nome = "BancoDados.db";
    private static int versao=1;

    public DBHelperProd(Context context){
        super(context, nome,null,versao);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String str = "CREATE TABLE produtos(PKidprod int PRIMARY KEY, nomeprod TEXT , precoprod TEXT);";
        db.execSQL(str);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS produtos;");
        onCreate(db);

    }
    public long criarProd(String nomeprod, String precoprod){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Doidão da vila",nomeprod);
        cv.put("R$ 60,00",precoprod);
        cv.put("Pavor dos vegetarianos",nomeprod);
        cv.put("R$ 40,00",precoprod);
        cv.put("Combo monstrão",nomeprod);
        cv.put("R$ 100,00",precoprod);
        cv.put("Suplemento de atleta",nomeprod);
        cv.put("R$ 50,00",precoprod);

        long result = db.insert("produtos", null,cv);

        return result;
    }

        }

